
<?php
  







require('./confige/list_conn.php');

require('./confige/list_ana_conn.php');



function getVisIpAddr() { 
      
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
        return $_SERVER['HTTP_CLIENT_IP']; 
    } 
    else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
        return $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } 
    else { 
        return $_SERVER['REMOTE_ADDR']; 
    } 
} 









function update_flg_of_camp_act($conn,$flg,$lst_name,$camp_name,$email){











$update_query_name="update `$lst_name` set `$camp_name`='$flg' where con_id='$email'";

$conn->query($update_query_name);





}


function sel_data_of_mail($conn,$chk,$lst_name,$camp_name,$email){


$sel_query_tab="select `$camp_name` from `$lst_name` where con_id='$email'";


$result = $conn->query($sel_query_tab);

  // output data of each row
  while($row = $result->fetch_assoc()) {
    if($row[$camp_name]>=$chk){


return false;

}
  }

return true;

}



function insert_date_data_in_ana_table($conn,$act,$id,$lst,$camp){


$ip_addr=getVisIpAddr();


$ipdat = @json_decode(file_get_contents( "http://www.geoplugin.net/json.gp?ip=" . $ip_addr)); 



$date = new DateTime("now", new DateTimeZone('America/Los_Angeles') );
$date_add=$date->format('Y-m-d H');

$cnt_cd=$ipdat->geoplugin_countryCode;





$tbl_name=$camp."#".$lst;


$isrt_query_of_pos_data="insert into `$tbl_name` values ('$id','$act','$cnt_cd','$date_add')";


$conn->query($isrt_query_of_pos_data);


}






$lst_name=$_GET['lst_name'];
$camp_name=$_GET['camp_name'];
$email=$_GET['con_id'];




if(sel_data_of_mail($conn_of_lst_data,3,$lst_name,$camp_name,$email)){


update_flg_of_camp_act($conn_of_lst_data,3,$lst_name,$camp_name,$email);

insert_date_data_in_ana_table($camp_ana_conn,3,$email,$lst_name,$camp_name);


}


?>


