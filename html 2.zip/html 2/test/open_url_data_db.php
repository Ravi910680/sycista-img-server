<?php
  





$servername = "hepteralogin.c86etdreadqr.us-east-2.rds.amazonaws.com";
$username = "gautam910";
$password = "Ravi91068";


$db_camp_ana="camp_analysis";

$camp_ana_conn = mysqli_connect($servername, $username, $password,$db_camp_ana);



function getVisIpAddr() { 
      
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
        return $_SERVER['HTTP_CLIENT_IP']; 
    } 
    else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
        return $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } 
    else { 
        return $_SERVER['REMOTE_ADDR']; 
    } 
} 









function sel_data_of_mail($conn,$chk,$lst_name,$camp_name,$email){




$tbl_name=$camp_name."#".$lst_name;



$sel_query_tab="select `$camp_name` from `$tbl_name` where id='$email' and act='$chk'";


$result = $conn->query($sel_query_tab);


  


if($result!=""){
return false;

}

return true;


}



function insert_date_data_in_ana_table($conn,$act,$id,$lst,$camp){


$ip_addr=getVisIpAddr();


$ipdat = @json_decode(file_get_contents( "http://www.geoplugin.net/json.gp?ip=" . $ip_addr)); 




$date = new DateTime("now", new DateTimeZone('America/Los_Angeles') );
$date_add=$date->format('Y-m-d H');

$cnt_cd=$ipdat->geoplugin_countryCode;


$reg_name=$ipdat->geoplugin_regionName;



$tbl_name=$camp."#".$lst;


$isrt_query_of_pos_data="insert into `$tbl_name` values ('$id','$act','$cnt_cd','$date_add','$reg_name')";


$conn->query($isrt_query_of_pos_data);


}






$lst_name=$_GET['lst_name'];

$camp_name=$_GET['camp_name'];

$ex_camp_name=explode("@", $camp_name);

$camp_name=$ex_camp_name[0];

$flg_tag=$ex_camp_name[1];


$email=$_GET['con_id'];





if(sel_data_of_mail($camp_ana_conn,$flg_tag,$lst_name,$camp_name,$email)){





insert_date_data_in_ana_table($camp_ana_conn,$flg_tag,$email,$lst_name,$camp_name);



}


?>
