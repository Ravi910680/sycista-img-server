<?php






function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


}



cors();





require("./confige/imagedir.conf.php");

require("./confige/imagesave.conf.php");









$img_name_del=$_POST["del_array"];

$dir_find_name=explode("^",$img_name_del[0]);
print_r($dir_find_name);
$dir_name=$dir_find_name[0]."^".$dir_find_name[1];

$image_dir_select="SELECT * FROM imagedirname WHERE dir='$dir_name'";

$result = $imagedir->query($image_dir_select);
$row = $result->fetch_assoc();
$count_saved=$row['count'];

$targetFilePath="images/";

foreach($img_name_del as $img_del){
    

$del_img_sql="DELETE FROM `".$dir_name."` WHERE image='$img_del'";

if($imagesave->query($del_img_sql)==TRUE){

if(unlink($targetFilePath.$img_del)){
$count_saved=$count_saved-1;
    echo "file deleted";
}

}



}


$count_update = "UPDATE imagedirname SET count='$count_saved' WHERE dir='$dir_name'";

$imagedir->query($count_update);


?>
