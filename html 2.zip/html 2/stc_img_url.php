<?php


$width_img=0;
$he_img=0;


function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

    
}



cors();





$_POST=$_GET;

function get_size_of_img(){




$id_of_img=$GLOBALS['targetFilePath'].$GLOBALS['image_db_name']; 
$size = getimagesize($id_of_img);

$GLOBALS['width_img']=$size[0];
$GLOBALS['he_img']=$size[1];





}






function file_get_contents_curl($url) { 
    $ch = curl_init(); 
  
    curl_setopt($ch, CURLOPT_HEADER, 0); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
    curl_setopt($ch, CURLOPT_URL, $url); 
  
    $data = curl_exec($ch); 
    curl_close($ch); 
  
    return $data; 
} 
  




$flg_for_res=0;

















require("./confige/imagedir.conf.php");

require("./confige/imagesave.conf.php");






$dir_name=$_POST['dir_name'];

$img_url=$_POST['img_url'];




$array_of_val_exe=array("png","jpg","jpeg","pdf","svg","gif");



$image_dir_select="SELECT * FROM imagedirname WHERE dir='$dir_name'";


$result = $imagedir->query($image_dir_select);
$row = $result->fetch_assoc();


$targetFilePath="images/";
$count_saved=$row['count'];
$all_count=$row["allcount"];

$img_url=explode("?",$img_url)[0];
$path_parts = pathinfo($img_url);
$file_ext=$path_parts['extension'];

if(strlen($file_ext)==0){

$file_ext='png';

}



$image_name=base64_decode(explode("^", $dir_name)[1])."-".$all_count.".".$file_ext;



$image_db_name=$dir_name."^".$all_count.".".$file_ext;

$fp = $targetFilePath.$image_db_name; 
if(in_array($file_ext,$array_of_val_exe)){



// Function to write image into file
$data=file_put_contents($fp, file_get_contents($img_url));



if($data){
$date=date("Y-m-d h:i:sa");



get_size_of_img();



$insert_img_data = "INSERT INTO `".$dir_name."`  VALUES ('$image_db_name', '$width_img', '$he_img',140,'$image_name','$date')";
echo $insert_img_data;
if($imagesave->query($insert_img_data)==TRUE){

$all_count=$all_count+1;
$count_saved=$count_saved+1;

  

}else{




echo $imagesave->error;

}


                

$count_update = "UPDATE imagedirname SET count='$count_saved',allcount='$all_count' WHERE dir='$dir_name'";

if($imagedir->query($count_update)=='true'){
	$flg_for_res=1;
}







}



}





echo $flg_for_res;


?>
