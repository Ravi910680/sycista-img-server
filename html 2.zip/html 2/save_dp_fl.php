<?php

function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


}



cors();




require_once 'Requests/library/Requests.php';

function dbx_get_file($token, $in_filepath, $out_filepath)
{


	Requests::register_autoloader();


$response =Requests::post("https://content.dropboxapi.com/2/files/download", array(
'Authorization' => "Bearer ".$token,
'Dropbox-Api-Arg' => json_encode(array('path' => $in_filepath)),
));


	$fileContent = $response->body;

	if(file_put_contents($out_filepath,$fileContent)){


return 1;

	}else{


		return 0;
	}

   
    } // dbx_get_file()





$fl_path=$_GET['fl_path'];
$fl_name=$_GET['fl_name'];
$acc_tok=$_GET['acc_tok'];










require("./confige/imagedir.conf.php");

require("./confige/imagesave.conf.php");








$id='19';


    $dir_name= $id."^Y2xvdWRfY29kZQ==";



$image_dir_select="SELECT * FROM imagedirname WHERE dir='$dir_name'";

$result = $imagedir->query($image_dir_select);
$row = $result->fetch_assoc();

$count_saved=$row['count'];
$all_count=$row["allcount"];
$targetFilePath="images/";


$path_parts = pathinfo($fl_path);

$file_ext=$path_parts['extension'];
$image_db_name=$dir_name."^".$all_count.".".$file_ext;



$metadata = dbx_get_file($acc_tok, $fl_path, $targetFilePath.$image_db_name);


if($metadata==1){

$image_info = getimagesize($targetFilePath.$image_db_name);
$width=$image_info[0];
$height=$image_info[1];
                $insert_img_data = "INSERT INTO `".$dir_name."`  VALUES ('$image_db_name', '$width', '$height','jk','$fl_name')";
                if($imagesave->query($insert_img_data)==TRUE){

$all_count=$all_count+1;
$count_saved=$count_saved+1;

echo 1;
                }

}




$count_update = "UPDATE imagedirname SET count='$count_saved',allcount='$all_count' WHERE dir='$dir_name'";

if($imagedir->query($count_update)=='true'){
	$flg_for_res=1;
}







?>

