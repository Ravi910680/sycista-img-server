<?php
$servername = "studio.cnenb266gjbe.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";


$dbname = "imagedir";

$imagedir = mysqli_connect($servername, $username, $password,$dbname);


?>

