<?php
  

function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }


}



cors();





require("./confige/imagedir.conf.php");

require("./confige/imagesave.conf.php");








$fold_name=$_GET['fold_old_name'];



$flg_suc=0;

$str_for_chk_crw="select * from imagedirname where dir='$fold_name' and extra='0'";
$res_of_check=$imagedir->query($str_for_chk_crw);

$rows_count=$res_of_check->num_rows;


if($rows_count){

$select_img_file="select * from `$fold_name`";

$all_file_name = $imagesave->query($select_img_file);


if ($all_file_name->num_rows > 0) {
    // output data of each row
    while($row = $all_file_name->fetch_assoc()) {
        
$rename_stat=unlink("./images/".$row['image']);


    }



$drop_tbls="drop table `$fold_name`";




if($imagesave->query($drop_tbls)==true){

	$delet_dir_name="delete from imagedirname where dir='$fold_name'";

	if($imagedir->query($delet_dir_name)==true){

		$flg_suc=1;
	}else{
		$flg_suc=0;
	}

}else{
  $flg_suc=0;
}




} else {
    

$drop_tbls="drop table `$fold_name`";



if($imagesave->query($drop_tbls)==true){

$delet_dir_name="delete from imagedirname where dir='$fold_name'";
        
        if($imagedir->query($delet_dir_name)==true){

                $flg_suc=1;
        }else{
                $flg_suc=0;
        }


}else{
  $flg_suc=0;
}




}


}


echo $flg_suc;


?>

